import { useState, useRef } from "react";

let _id = 1;
const uid = () => `${_id++}`;

const INIT_CAFES = [];
const mkOrder = () => ({ menuId: null, customItem: '', temp: 'HOT', memo: '', confirmed: false });

const C = {
  bg: '#FDFAF5', white: '#FFFFFF',
  gold: '#B8902E', goldL: '#F5EDD8', goldF: '#FBF8F0',
  text: '#1C1714', mid: '#6B5B4E', mute: '#A89282', border: '#E8DDD0',
  green: '#3A6647', greenL: '#EDF6F1', greenB: '#9FD4B5',
};

export default function App() {
  const [cafes, setCafes] = useState(INIT_CAFES);
  const [cafeId, setCafeId] = useState(null);
  const [members, setMembers] = useState([]);
  const [nameInput, setNameInput] = useState('');
  const [editId, setEditId] = useState(null);
  const [showSummary, setShowSummary] = useState(false);
  const [showMenuModal, setShowMenuModal] = useState(false);
  const [showNewCafe, setShowNewCafe] = useState(false);
  const [newCafeName, setNewCafeName] = useState('');
  const [bulkInput, setBulkInput] = useState('');
  const [singleInput, setSingleInput] = useState('');

  const nameRef = useRef();
  const cafe = cafes.find(c => c.id === cafeId);

  /* ── Members ── */
  const addMembers = () => {
    const names = nameInput.split(/[,，\s]+/).map(n => n.trim()).filter(Boolean);
    if (!names.length) return;
    setMembers(p => [...p, ...names.map(n => ({ id: uid(), name: n, order: mkOrder() }))]);
    setNameInput('');
    nameRef.current?.focus();
  };

  const upd = (id, patch) =>
    setMembers(p => p.map(m => m.id === id ? { ...m, order: { ...m.order, ...patch } } : m));
  const confirmOrd = (id) => { upd(id, { confirmed: true }); setEditId(null); };
  const editOrd   = (id) => { upd(id, { confirmed: false }); setEditId(id); };
  const removeMember = (id) => {
    setMembers(p => p.filter(m => m.id !== id));
    if (editId === id) setEditId(null);
  };

  /* ── Menu management ── */
  const addBulk = () => {
    const names = bulkInput.split(/[,，]+/).map(n => n.trim()).filter(Boolean);
    if (!names.length) return;
    setCafes(p => p.map(c => c.id === cafeId
      ? { ...c, menu: [...c.menu, ...names.map(name => ({ id: uid(), name }))] }
      : c));
    setBulkInput('');
  };

  const addSingle = () => {
    if (!singleInput.trim()) return;
    setCafes(p => p.map(c => c.id === cafeId
      ? { ...c, menu: [...c.menu, { id: uid(), name: singleInput.trim() }] }
      : c));
    setSingleInput('');
  };

  const delMenuItem = (itemId) =>
    setCafes(p => p.map(c => c.id === cafeId
      ? { ...c, menu: c.menu.filter(m => m.id !== itemId) }
      : c));

  const createCafe = () => {
    if (!newCafeName.trim()) return;
    const nc = { id: uid(), name: newCafeName.trim(), menu: [] };
    setCafes(p => [...p, nc]);
    setCafeId(nc.id);
    setNewCafeName(''); setShowNewCafe(false); setShowMenuModal(true);
  };

  /* ── Order helpers ── */
  const getLabel = (order) =>
    order.customItem?.trim() || cafe?.menu.find(x => x.id === order.menuId)?.name || '';
  const hasSel = (order) => !!(order.menuId || order.customItem?.trim());

  const ordered   = members.filter(m => m.order.confirmed && hasSel(m.order));
  const unordered = members.filter(m => !m.order.confirmed || !hasSel(m.order));

  const counts = ordered.reduce((acc, m) => {
    const label = getLabel(m.order);
    if (!label) return acc;
    const k = `${label}${m.order.temp === 'ICE' ? ' (아이스)' : ''}`;
    return { ...acc, [k]: [...(acc[k] || []), m.order.memo || ''] };
  }, {});

  const fmtMemos = (memos) => {
    if (memos.every(s => !s)) return null;
    const g = {};
    memos.forEach(s => { const key = s || '보통'; g[key] = (g[key] || 0) + 1; });
    return Object.entries(g).map(([k, v]) => `${v}잔 ${k}`).join(', ');
  };

  const copyText = () => {
    const lines = [
      `☕ ${cafe?.name} 주문 목록`, '─────────────────',
      ...ordered.map(m =>
        `${m.name}: ${getLabel(m.order)}${m.order.temp === 'ICE' ? ' (아이스)' : ''}${m.order.memo ? ' — ' + m.order.memo : ''}`
      ),
      '', '📋 수량 요약',
      ...Object.entries(counts).map(([k, memos]) => {
        const d = fmtMemos(memos);
        return `${k}: ${memos.length}잔${d ? ` (${d})` : ''}`;
      }),
    ].join('\n');
    navigator.clipboard?.writeText(lines);
  };

  /* ── Shared styles ── */
  const modalBg = {
    position: 'fixed', inset: 0, background: 'rgba(28,23,20,0.38)',
    backdropFilter: 'blur(6px)', display: 'flex', alignItems: 'center',
    justifyContent: 'center', zIndex: 200, padding: 16,
  };
  const modalBox = {
    background: C.white, borderRadius: 22, width: '100%', maxWidth: 500,
    maxHeight: '88vh', boxShadow: '0 24px 80px rgba(0,0,0,0.16)',
    display: 'flex', flexDirection: 'column',
  };

  return (
    <div style={{ minHeight: '100vh', background: `radial-gradient(ellipse at 20% 10%, #FEF3D4 0%, ${C.bg} 55%)`, fontFamily: "'Noto Sans KR', sans-serif", color: C.text }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;1,400&family=Noto+Sans+KR:wght@300;400;500;700&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        ::placeholder{color:#C4B4A4}
        input,textarea,button,select{font-family:'Noto Sans KR',sans-serif}
        @keyframes fadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
        .fade{animation:fadeUp .2s ease forwards}
        .gbtn{background:#B8902E;color:#fff;border:none;border-radius:10px;padding:11px 20px;font-size:14px;font-weight:500;cursor:pointer;transition:background .15s;white-space:nowrap}
        .gbtn:hover{background:#9A7829}
        .gbtn:disabled{background:#DACCAE;cursor:default;color:rgba(255,255,255,.5)}
        .ghost{background:#fff;color:#B8902E;border:1.5px solid #E8DDD0;border-radius:10px;padding:9px 16px;font-size:13px;cursor:pointer;transition:all .15s;white-space:nowrap}
        .ghost:hover{border-color:#B8902E;background:#FBF8F0}
        .tinput{background:#fff;border:1.5px solid #E8DDD0;border-radius:10px;padding:11px 14px;font-size:14px;color:#1C1714;outline:none;transition:border-color .15s;width:100%}
        .tinput:focus{border-color:#B8902E;box-shadow:0 0 0 3px rgba(184,144,46,.07)}
        .mchip{display:flex;align-items:center;padding:11px 14px;border-radius:10px;border:1.5px solid transparent;cursor:pointer;transition:all .12s;background:#FDFAF5;font-size:14px;color:#1C1714}
        .mchip:hover{border-color:#E8DDD0;background:#fff}
        .mchip.sel{border-color:#B8902E;background:#FBF8F0;font-weight:500}
        .tbtn{padding:7px 20px;border-radius:20px;border:1.5px solid #E8DDD0;background:transparent;color:#6B5B4E;font-size:13px;cursor:pointer;transition:all .13s}
        .tbtn.sel{border-color:#B8902E;background:#B8902E;color:#fff}
        .card{background:#fff;border-radius:16px;border:1px solid #E8DDD0;box-shadow:0 2px 16px rgba(140,100,50,.06)}
        .label{font-size:10px;letter-spacing:3px;color:#A89282;text-transform:uppercase;font-weight:500;margin-bottom:10px}
        ::-webkit-scrollbar{width:4px}::-webkit-scrollbar-thumb{background:#D4C0A0;border-radius:2px}
      `}</style>

      {/* ── HEADER ── */}
      <header style={{ background: C.white, borderBottom: `1px solid ${C.border}`, position: 'sticky', top: 0, zIndex: 50 }}>
        <div style={{ maxWidth: 600, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 20px', height: 62 }}>
          <div>
            <div style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 22, fontWeight: 600, color: C.gold, letterSpacing: 0.5 }}>커피주문</div>
            <div style={{ fontSize: 9, letterSpacing: 4, color: C.mute, marginTop: 1, textTransform: 'uppercase', fontWeight: 300 }}>Order Together</div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
            <div style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 15, letterSpacing: 6, color: C.gold, fontStyle: 'italic' }}>YEEUN</div>
            <div style={{ width: 40, height: 1, background: `linear-gradient(90deg, transparent, ${C.gold})`, marginTop: 3 }} />
          </div>
        </div>
      </header>

      {/* ── WARNING BANNER ── */}
      <div style={{ background: '#FEF9EC', borderBottom: `1px solid #F0DFA0`, padding: '9px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
        <div style={{ fontSize: 12, color: '#7A6020', display: 'flex', alignItems: 'center', gap: 6 }}>
          <span>⚠️</span>
          <span>입력한 자료는 저장되지 않습니다. 창을 닫거나 새로고침하면 초기화됩니다.</span>
        </div>
        <button
          onClick={() => { if (window.confirm('모든 입력 내용이 초기화됩니다. 계속하시겠습니까?')) window.location.reload(); }}
          style={{ background: 'none', border: `1px solid #D4B84A`, borderRadius: 8, padding: '4px 12px', fontSize: 12, color: '#7A6020', cursor: 'pointer', whiteSpace: 'nowrap', fontFamily: 'inherit' }}>
          🔄 새로고침
        </button>
      </div>
      <main style={{ maxWidth: 600, margin: '0 auto', padding: '20px 16px 100px' }}>

        {/* CAFE */}
        <div className="card" style={{ padding: 20, marginBottom: 14 }}>
          <div className="label">카페 선택</div>
          {cafes.length === 0 ? (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '16px 0', gap: 12 }}>
              <div style={{ fontSize: 14, color: C.mute, textAlign: 'center' }}>
                카페를 먼저 추가해주세요
              </div>
              <button className="gbtn" onClick={() => setShowNewCafe(true)}>+ 새 카페 추가</button>
            </div>
          ) : (
            <>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
                <div style={{ position: 'relative', flex: 1, minWidth: 140 }}>
                  <select value={cafeId || ''} onChange={e => setCafeId(e.target.value)}
                    style={{ width: '100%', appearance: 'none', background: C.goldF, border: `1.5px solid ${C.border}`, borderRadius: 10, padding: '11px 34px 11px 14px', fontSize: 15, fontWeight: 500, color: C.text, cursor: 'pointer', outline: 'none' }}>
                    {cafes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                  <span style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', color: C.gold, pointerEvents: 'none', fontSize: 12 }}>▾</span>
                </div>
                <button className="ghost" onClick={() => setShowMenuModal(true)}>메뉴 관리</button>
                <button className="ghost" onClick={() => setShowNewCafe(true)}>+ 새 카페</button>
              </div>
              {cafe?.menu.length > 0 && (
                <div style={{ marginTop: 12, display: 'flex', flexWrap: 'wrap', gap: 5 }}>
                  {cafe.menu.slice(0, 8).map(m => (
                    <span key={m.id} style={{ padding: '3px 10px', borderRadius: 20, background: C.goldL, color: C.mid, fontSize: 11, fontWeight: 500 }}>{m.name}</span>
                  ))}
                  {cafe.menu.length > 8 && (
                    <span style={{ padding: '3px 10px', borderRadius: 20, background: C.border, color: C.mute, fontSize: 11 }}>+{cafe.menu.length - 8}</span>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        {/* MEMBERS */}
        <div className="card" style={{ padding: 20, marginBottom: 14 }}>
          <div className="label">인원 추가</div>
          <div style={{ display: 'flex', gap: 8 }}>
            <input ref={nameRef} className="tinput" value={nameInput}
              onChange={e => setNameInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && addMembers()}
              placeholder="효진, 혜영, 동민, 강산 (쉼표로 여러 명)" />
            <button className="gbtn" onClick={addMembers}>추가</button>
          </div>
          {members.length > 0 && (
            <div style={{ marginTop: 12, display: 'flex', flexWrap: 'wrap', gap: 7 }}>
              {members.map(m => (
                <div key={m.id} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '4px 8px 4px 12px', borderRadius: 20, background: m.order.confirmed ? C.greenL : C.goldF, border: `1px solid ${m.order.confirmed ? C.greenB : C.border}`, fontSize: 13, color: m.order.confirmed ? C.green : C.mid, fontWeight: 500, transition: 'all .2s' }}>
                  {m.order.confirmed && <span style={{ fontSize: 10 }}>✓</span>}
                  {m.name}
                  <button onClick={() => removeMember(m.id)} style={{ background: 'none', border: 'none', color: C.mute, cursor: 'pointer', fontSize: 15, padding: '0 2px', lineHeight: 1, marginLeft: 2 }}>×</button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ORDER CARDS */}
        {members.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 20px' }}>
            <div style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 56, marginBottom: 14, opacity: .2 }}>☕</div>
            <div style={{ fontSize: 15, color: C.mid, fontWeight: 300 }}>인원을 추가하고 주문을 시작하세요</div>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {members.map(m => {
              const isEditing  = editId === m.id && !m.order.confirmed;
              const orderLabel = getLabel(m.order);
              return (
                <div key={m.id} style={{ background: C.white, borderRadius: 16, border: `1.5px solid ${isEditing ? C.gold : m.order.confirmed ? C.greenB : C.border}`, boxShadow: isEditing ? `0 6px 30px rgba(184,144,46,.12)` : '0 1px 8px rgba(140,100,50,.04)', transition: 'border-color .2s, box-shadow .2s', overflow: 'hidden' }}>

                  {/* Card header */}
                  <div
                    style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', cursor: m.order.confirmed ? 'default' : 'pointer', background: isEditing ? C.goldF : 'transparent', borderBottom: isEditing ? `1px solid ${C.border}` : 'none', transition: 'background .2s' }}
                    onClick={() => !m.order.confirmed && setEditId(isEditing ? null : m.id)}
                  >
                    <div style={{ width: 40, height: 40, borderRadius: '50%', background: m.order.confirmed ? `linear-gradient(135deg, ${C.green}, #5EA87A)` : `linear-gradient(135deg, ${C.gold}, #E8C060)`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: 16, flexShrink: 0, transition: 'background .3s' }}>
                      {m.name[0]}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontWeight: 700, fontSize: 15 }}>{m.name}</div>
                      <div style={{ fontSize: 12, marginTop: 3, color: m.order.confirmed ? C.green : orderLabel ? C.gold : C.mute }}>
                        {m.order.confirmed
                          ? `${orderLabel}${m.order.temp === 'ICE' ? ' · 아이스' : ''}${m.order.memo ? ' · ' + m.order.memo : ''}`
                          : orderLabel ? `${orderLabel} — 확정 전`
                          : isEditing ? '메뉴를 선택하세요' : '탭하여 주문 입력'}
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexShrink: 0 }}>
                      {m.order.confirmed ? (
                        <>
                          <span style={{ fontSize: 18 }}>✅</span>
                          <button className="ghost" onClick={e => { e.stopPropagation(); editOrd(m.id); }} style={{ padding: '4px 10px', fontSize: 12 }}>수정</button>
                        </>
                      ) : (
                        <span style={{ color: C.border, fontSize: 22, lineHeight: 1, transform: isEditing ? 'rotate(90deg)' : 'none', transition: 'transform .2s' }}>›</span>
                      )}
                    </div>
                  </div>

                  {/* Order panel */}
                  {isEditing && (
                    <div className="fade" style={{ padding: 16 }}>

                      {/* TOP: 온도 + 메모 + 확정 */}
                      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
                        {['HOT', 'ICE'].map(t => (
                          <button key={t} className={`tbtn${m.order.temp === t ? ' sel' : ''}`} onClick={() => upd(m.id, { temp: t })}>
                            {t === 'HOT' ? '🔥 HOT' : '🧊 ICE'}
                          </button>
                        ))}
                        <input className="tinput" value={m.order.memo}
                          onChange={e => upd(m.id, { memo: e.target.value })}
                          placeholder="메모 (두유, 샷추가…)"
                          style={{ flex: 1, padding: '7px 12px', fontSize: 13 }} />
                      </div>
                      <button className="gbtn" style={{ width: '100%', padding: 12, marginBottom: 16 }}
                        disabled={!hasSel(m.order)}
                        onClick={() => hasSel(m.order) && confirmOrd(m.id)}>
                        ✓ 주문 확정
                      </button>

                      {/* MIDDLE: 메뉴 리스트 */}
                      <div className="label">메뉴 선택</div>
                      <div style={{ maxHeight: 220, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 3, marginBottom: 14 }}>
                        {cafe?.menu.map(item => (
                          <div key={item.id}
                            className={`mchip${m.order.menuId === item.id && !m.order.customItem ? ' sel' : ''}`}
                            onClick={() => upd(m.id, { menuId: item.id, customItem: '' })}>
                            {item.name}
                          </div>
                        ))}
                      </div>

                      {/* BOTTOM: 기타 메뉴 */}
                      <div style={{ borderTop: `1px dashed ${C.border}`, paddingTop: 12 }}>
                        <div className="label">기타 메뉴 직접 입력</div>
                        <input className="tinput" value={m.order.customItem}
                          onChange={e => upd(m.id, { customItem: e.target.value, menuId: e.target.value.trim() ? null : m.order.menuId })}
                          placeholder="메뉴판에 없는 경우 직접 입력"
                          style={{ borderColor: m.order.customItem ? C.gold : undefined }} />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* PROGRESS + CTA */}
        {members.length > 0 && (
          <div className="card" style={{ padding: 18, marginTop: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10, fontSize: 13 }}>
              <span style={{ color: C.mid }}>완료 <b style={{ color: C.green, fontSize: 15 }}>{ordered.length}</b> / {members.length}명</span>
              {unordered.length > 0 && (
                <span style={{ color: C.mute, fontSize: 12 }}>대기: {unordered.map(m => m.name).join(', ')}</span>
              )}
            </div>
            <div style={{ height: 5, borderRadius: 3, background: C.border, marginBottom: 14, overflow: 'hidden' }}>
              <div style={{ height: '100%', width: `${members.length ? (ordered.length / members.length) * 100 : 0}%`, background: `linear-gradient(90deg, ${C.gold}, #E8C060)`, borderRadius: 3, transition: 'width .45s ease' }} />
            </div>
            <button className="gbtn" style={{ width: '100%', padding: 14, fontSize: 15 }}
              disabled={!ordered.length} onClick={() => setShowSummary(true)}>
              주문 목록 보기
            </button>
          </div>
        )}
      </main>

      {/* ── SUMMARY MODAL ── */}
      {showSummary && (
        <div style={modalBg} onClick={() => setShowSummary(false)}>
          <div className="fade" style={modalBox} onClick={e => e.stopPropagation()}>
            <div style={{ padding: '22px 24px 16px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
              <div>
                <div style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 22, fontWeight: 600 }}>주문 목록</div>
                <div style={{ fontSize: 12, color: C.mute, marginTop: 2 }}>{cafe?.name} · {ordered.length}명</div>
              </div>
              <button onClick={() => setShowSummary(false)} style={{ background: 'none', border: 'none', color: C.mute, cursor: 'pointer', fontSize: 24, lineHeight: 1 }}>×</button>
            </div>

            <div style={{ flex: 1, overflowY: 'auto', padding: '16px 24px' }}>
              {/* 인원별 */}
              {ordered.map(m => {
                const label = getLabel(m.order);
                return (
                  <div key={m.id} style={{ display: 'flex', alignItems: 'flex-start', padding: '11px 0', borderBottom: `1px solid ${C.border}` }}>
                    <div style={{ width: 32, height: 32, borderRadius: '50%', background: `linear-gradient(135deg, ${C.green}, #5EA87A)`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: 13, flexShrink: 0, marginRight: 12 }}>
                      {m.name[0]}
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 700, fontSize: 14 }}>{m.name}</div>
                      <div style={{ fontSize: 13, color: C.mid, marginTop: 2, display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center' }}>
                        <span>{label}</span>
                        {m.order.temp === 'ICE' && (
                          <span style={{ color: '#3A8CC0', fontSize: 11, fontWeight: 600, background: '#E8F4FB', padding: '1px 7px', borderRadius: 10 }}>아이스</span>
                        )}
                        {m.order.memo && <span style={{ color: C.mute }}>· {m.order.memo}</span>}
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* 수량 요약 */}
              <div style={{ background: C.goldF, borderRadius: 12, padding: '14px 16px', margin: '16px 0 0', border: `1px solid ${C.goldL}` }}>
                <div className="label">수량 요약</div>
                {Object.entries(counts).map(([k, memos]) => {
                  const detail = fmtMemos(memos);
                  return (
                    <div key={k} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                      <div style={{ flex: 1 }}>
                        <span style={{ fontSize: 14, color: C.mid }}>{k}</span>
                        {detail && <div style={{ fontSize: 11, color: C.mute, marginTop: 3 }}>({detail})</div>}
                      </div>
                      <span style={{ fontWeight: 700, fontSize: 15, color: C.text, marginLeft: 12 }}>{memos.length}잔</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div style={{ padding: '16px 24px', borderTop: `1px solid ${C.border}`, flexShrink: 0, display: 'flex', gap: 10 }}>
              <button className="ghost" style={{ flex: 1 }} onClick={copyText}>📋 텍스트 복사</button>
              <button className="gbtn" style={{ flex: 1 }} onClick={() => setShowSummary(false)}>닫기</button>
            </div>
          </div>
        </div>
      )}

      {/* ── MENU EDITOR MODAL ── */}
      {showMenuModal && (
        <div style={modalBg} onClick={() => setShowMenuModal(false)}>
          <div className="fade" style={modalBox} onClick={e => e.stopPropagation()}>
            <div style={{ padding: '20px 22px 16px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
              <div>
                <div style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 20, fontWeight: 600 }}>{cafe?.name}</div>
                <div style={{ fontSize: 11, color: C.mute, marginTop: 2 }}>메뉴 관리</div>
              </div>
              <button onClick={() => setShowMenuModal(false)} style={{ background: 'none', border: 'none', color: C.mute, cursor: 'pointer', fontSize: 24 }}>×</button>
            </div>

            {/* 일괄 추가 */}
            <div style={{ padding: '16px 22px', borderBottom: `1px solid ${C.border}`, background: C.goldF, flexShrink: 0 }}>
              <div className="label">메뉴 일괄 추가</div>
              <div style={{ display: 'flex', gap: 8 }}>
                <input className="tinput" value={bulkInput}
                  onChange={e => setBulkInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && addBulk()}
                  placeholder="아메리카노, 라떼, 과일주스 (쉼표로 구분)" />
                <button className="gbtn" onClick={addBulk} style={{ padding: '10px 16px' }}>추가</button>
              </div>
            </div>

            {/* 메뉴 리스트 */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '12px 22px' }}>
              {!cafe?.menu.length ? (
                <div style={{ textAlign: 'center', color: C.mute, padding: '32px 0', fontSize: 14 }}>
                  위에서 메뉴를 추가해주세요.
                </div>
              ) : cafe.menu.map(item => (
                <div key={item.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '9px 0', borderBottom: `1px solid ${C.border}` }}>
                  <span style={{ fontSize: 14, color: C.text }}>{item.name}</span>
                  <button onClick={() => delMenuItem(item.id)} style={{ background: 'none', border: 'none', color: '#D09090', cursor: 'pointer', fontSize: 20, lineHeight: 1, padding: '0 4px' }}>×</button>
                </div>
              ))}
            </div>

            {/* 개별 추가 */}
            <div style={{ padding: '14px 22px', borderTop: `1px solid ${C.border}`, flexShrink: 0 }}>
              <div className="label">개별 추가</div>
              <div style={{ display: 'flex', gap: 8 }}>
                <input className="tinput" value={singleInput}
                  onChange={e => setSingleInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && addSingle()}
                  placeholder="메뉴명 입력" />
                <button className="gbtn" onClick={addSingle} style={{ padding: '10px 16px' }}>추가</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── NEW CAFE MODAL ── */}
      {showNewCafe && (
        <div style={modalBg} onClick={() => setShowNewCafe(false)}>
          <div className="fade" style={{ background: C.white, borderRadius: 20, width: '100%', maxWidth: 380, padding: 26, boxShadow: '0 24px 80px rgba(0,0,0,.16)' }} onClick={e => e.stopPropagation()}>
            <div style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 20, fontWeight: 600, marginBottom: 6 }}>새 카페 추가</div>
            <div style={{ fontSize: 13, color: C.mute, marginBottom: 18 }}>카페 이름을 입력하면 메뉴 관리 화면으로 이동합니다.</div>
            <input className="tinput" value={newCafeName}
              onChange={e => setNewCafeName(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && createCafe()}
              placeholder="카페 이름" style={{ marginBottom: 14 }} autoFocus />
            <div style={{ display: 'flex', gap: 10 }}>
              <button className="ghost" style={{ flex: 1 }} onClick={() => setShowNewCafe(false)}>취소</button>
              <button className="gbtn" style={{ flex: 1 }} onClick={createCafe}>만들기 →</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
